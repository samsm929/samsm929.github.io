function openHome() {
    $('.pages').show();
    $('.pages').not("#home").hide();
}

function openPage1() {
    $('.pages').show();
    $('.pages').not("#page1").hide();
}

function openPage2() {
    $('.pages').show();
    $('.pages').not("#page2").hide();
}